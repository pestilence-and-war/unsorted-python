# (x+6y = 1475)/[0,245]

goal = 1475
base = range(0,245)
adder = range(1,1475)
mult = 6


for x in base:
    print(x)
    for y in adder:
        #print(y)
        if x + (mult * y) > goal:
            continue
        if x + (mult * y) == goal:
            print(x, y)