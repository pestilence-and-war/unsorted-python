inventory = {'rope': 1, 'torch': 6, 'gold coin': 42, 'dagger': 1, 'arrow': 12}
dragonLoot = ['dragon penis','gold coin','gold coin', 'ruby', 'rope', 'torch']

def displayInventory(inventory):
    '''displays the current inventory'''
    print('Inventory:')

    for k,v in inventory.items():
        print(str(k)+'   '+str(v))

def addInventory(addedItem = None):
    '''compares a list of new items to the current inventory
    and increments currently held items, and adds new items
    to inventory if necessary'''
    if addedItem == None:
        displayInventory(inventory)
    else:
        for item in addedItem:
            if item not in inventory:
                inventory.setdefault(str(item), 1)
            else:
                inventory[item] += 1

displayInventory(inventory)
print('')
for i in range(100):
    addInventory(dragonLoot)
addInventory()