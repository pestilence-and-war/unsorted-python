'''2520 is the smallest number that can be divided by each 
of the numbers from 1 to 10 without any remainder.

What is the smallest positive number that is evenly
divisible by all of the numbers from 1 to 20?
** this code can do the case for any given number if you
have a large enough list of primes'''
from a import prime_numbers#this contains the list of primes to 1000000
list_of_primes = prime_numbers()#make this list any size you want, as long as it only
#contains prime numbers in ascending order starting from 2

def divisible_to(lim):#lim is sequential factors up to lim
    list_of_prod = []#blank list to math on
    result = 1 #cannot be 0 or result will never be above 0
    for item in list_of_primes:#loop through each value in the list
        prod = 1#resets for each value; is 1 for base case
        if item <= lim:#check current value in list_of_primes is less than the limit
            while prod ** item <= lim:#checks raised item doesn't excede the limit
                #stopping when the limit is exceded ONLY looping items as many times
                #as necessary to go above limit
                prod += 1 #increment the base of the condition
                result = result * item#multiplies all past vales which passed the check
                #the number of times they passed the check
                list_of_prod.append(item)#used to manually check code, can be deleted
    print (list_of_prod)
    return result

print(divisible_to(20))