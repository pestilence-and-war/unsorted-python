'''The sum of the primes below 10 is 2 + 3 + 5 + 7 = 17.

Find the sum of all the primes below two million.'''
import time
time_start = time.time()
time_stop = time.time()
def init_list(limit):#creates a list
    p = 1
    step = 2
    in_list = [item for item in xrange(p,limit,step)]
    in_list.insert(1,2)
    in_list.remove(1)
    return in_list

def derive_primes(limit):
    derived_primes = init_list(limit)
    p = 2
    while p<= derived_primes[-1]**.5:
        for item in derived_primes:
            if item != p:
                if item % p == 0:
                    derived_primes.remove(item)
        p += 1
    return sum(derived_primes)
time_start
print (derive_primes(100))
time_stop
print(time_stop - time_start)