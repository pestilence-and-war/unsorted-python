import pyperclip

spam = 1, 2, 3

pyperclip.copy(spam)
pyperclip.print()