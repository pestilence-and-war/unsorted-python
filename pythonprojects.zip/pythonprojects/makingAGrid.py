
# coding: utf-8

# In[ ]:


def ends(num):
    if num%2 != 0:
        print('+'+' - - - - +'*num)
        
    else:
        print('+ - - - - '*num +'+')
    
def lines(num):
    if num%2 != 0:
        print('|'+'         |'*num)
        
    else:
        print('|         '*num +'|')

def boxW(w):
    if w >= 1:
        ends(w)
        lines(w)
        lines(w)
        lines(w)
        lines(w)
        ends(w)

def boxH(h):
    if h >= 1:
        lines(h)
        lines(h)
        lines(h)
        lines(h)
        ends(h)

def box(w, h):
    boxW(w)
    boxH(h)

def grid(n):
    box(n,n)


# In[ ]:


print('How big is the grid?')
uinput = int(input())
grid(uinput)

