def factorial(n):
    if n == 0:
        return 1
    else:
        recurse = factorial(n-1)
        result = n * recurse
        return result

def factorialy(n):
    a = 0
    b = 1
    c = 1
    while c < n:
        #print(a)
        a, b = b, a + b #called tuple unpacking updates both simultaneously
        c+=1
    return a

print(factorialy(51))