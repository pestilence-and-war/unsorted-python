def writeBack():
    print('go ahead and type something')
    string = raw_input()
    n = -1

    for char in string:
        print(string[n])
        n = n-1

writeBack()