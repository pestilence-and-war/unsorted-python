def is_double(word):
    i = 0
    count = 0
    while i < len(word)-1:
        if word[i] == word[i+1]:
            count = count + 1
            if count == 2:
                return True
            i = i + 2
        else:
            count = 0
            i = i + 1
    return False

def triple_double():
    fin = open('words.txt')
    for line in fin:
        word = line.strip()
        if is_double(word):
            print(word)


def odometer():
    from euler_4 import palindrome_check
    n = 99999
    while  n < 999999:
        n+=1
        i = 0
        if palindrome_check(str(n - i)[i:]):
            i+=1
            if palindrome_check(str(n - i)[i:]):
                i+=1
                if palindrome_check(str(n - i)[i:]):
                    print(n)
                    print(n-1)
                    print(n-2)
                    break

'''fin = open('words.txt')
count = 0
x = fin.read().splitlines()
var = (x[0:15])
for i in var:
    count+=1
fin.close()'''

