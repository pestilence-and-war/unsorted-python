
# coding: utf-8

# In[ ]:


inventory = {"rope": 1, "torch": 6, "gold coin": 42, "dagger": 1, "arrow": 12}
dragonLoot= ["gold coin", "dagger", "gold coin", "gold coin", "ruby"]

#definitions/methods are not ran on declaration
def displayInventory(inventory):
    print("Inventory:")
    print()#space
    item_total = 0
    for k, v in inventory.items(): #k,v = key, value
        print(v, k) #can swap to print key or value first
        item_total += v#adds the values to the total
    print()#space
    print("Total number of itmes: " + str(item_total))
    
displayInventory(inventory)#run method on inventory


# In[ ]:


def addToInventory(inventory, addedItems):#the (items, here) are
#arguments taken by the function
    for i in range(len(addedItems)):#for every item in the list do...
        inventory.setdefault(addedItems[i],0)#replaces "if not in"
#arguemnt, adds the new key and sets the new key's value = 0
        inventory[addedItems[i]] = inventory[addedItems[i]]+1
#increments the recognized or new key value by 1
    return inventory # stops execution and hands the value back
#to the caller, also seems to update the variable(dictionary)

inv = inventory
#inv = {"gold coin": 42, "rope": 1}
inv = addToInventory(inv, dragonLoot)

displayInventory(inv)

