'''Each new term in the Fibonacci sequence is generated 
by adding the previous two terms. By starting with 
1 and 2, the first 10 terms will be:

1, 2, 3, 5, 8, 13, 21, 34, 55, 89, ...

By considering the terms in the Fibonacci sequence whose 
values do not exceed four million, find the sum of the 
even-valued terms.'''

def fibo(val):
    count = 1
    sequence = [1,1]
    result = 0
    while count<= val:
        for item in sequence:
            if item <= 4000000:
                sequence.append(sequence[count] + sequence[(count-1)])
                count += 1
            else:
                result = sum(even_values(sequence))
                return result

def even_values(list_obj):
    even_list = []
    for number in list_obj:
        if number % 2 == 0:
            even_list.append(number)
    print(even_list)
    return even_list