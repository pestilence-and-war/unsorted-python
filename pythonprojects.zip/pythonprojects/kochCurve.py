from swampy.TurtleWorld import*
import math

world = TurtleWorld()
bob = Turtle()
bob.delay = 0
print (bob)

def draw(t, length, n):
    if n == 0:
        return
    angle = 50
    fd(t, length*n)
    lt(t, angle)
    draw(t, length, n-1)
    rt(t, 2*angle)
    draw(t, length, n-1)
    lt(t, angle)
    bk(t, length*n)

def kochLine(t,length):
    x = length/3

    angle = 60
    fd(t, x/3)
    lt(t, angle)
    fd(t, x/3)
    rt(t, angle*2)
    fd(t, x/3)
    lt(t, angle)
    fd(t, x/3)

def koch(t, length):
    angle = 60
    kochLine(t, length)
    lt(t, angle)
    kochLine(t,length)
    rt(t,angle*2)
    kochLine(t, length)
    lt(t, angle)
    kochLine(t, length)

def snowFlake(t, length):
    for item in range(1):
        angle = 60
        koch(t, length)
        lt(t, angle)
        koch(t,length)
        rt(t,angle*2)
        koch(t, length)
        lt(t, angle)
        koch(t, length)
def snow(t, length):
        for i in range (3):
                snowFlake(t,length)
                rt(t, 120)

def deadTree():
    draw(bob, 7, 8)
#deadTree()
bob.x = -175
bob.y = 75
bob.redraw()

snow(bob,100)
world.mainloop()