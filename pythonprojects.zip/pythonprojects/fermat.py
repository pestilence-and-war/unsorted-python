import math

def numbers():
    print('Value for a')
    a = int(raw_input())
    print('Value for b')
    b = int(raw_input())
    print('value for c')
    c = int(raw_input())
    print('value for n')
    n = int(raw_input())
    check(a,b,c,n)

def check(a,b,c,n):
    if (a**n) + (b**n) == (c**n) & n!=2:
    #if (3**4) + (2**4) == (6**4):
        print('busted!!')
    else:
        print(str((a**n)+(b**n)) + ' is not equal to ' + str((c**n)))
        print('try again')

numbers()