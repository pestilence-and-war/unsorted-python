from swampy.TurtleWorld import*
import math

world = TurtleWorld()
bob = Turtle()
bob.delay = 0.01
print (bob)


def square(t,length):
    for i in range(4):
        fd(t, length)
        lt(t)

def polygon(t, n, length):
    angle = (360.0 / n)
    polyline(t, n, length, angle)
    """draws a series of lines using 'n' number of line segments
    at an angle in degrees, and the length, t is turtle """

def circle (t, r):
        arc(t, r, 360)

def arc(t, r, angle):
    arcLength = 2 * math.pi * r * angle / 360
    n = int (arcLength / 3) + 1
    stepLength = arcLength / n
    stepAngle = float(angle) / n
    polyline(t, n, stepLength, stepAngle)

def polyline(t, n, length, angle):
        """Draws n line segments with the given length and angle
        (in degrees) between them. t is a turtle. """
        for i in range(n):
                fd(t, length)
                lt(t, angle)

square (bob,100)
polygon (bob, 5, 50)
circle (bob,50)
wait_for_user()