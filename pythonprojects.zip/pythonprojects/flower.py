from exercise4_1 import *

world = TurtleWorld()
bob = Turtle()
bob.delay = 0.001

def petal(t,r,angle):
    for i in range(2):
        arc(t, r, angle)
        lt(t, 180 - angle)

def flower (t,n,r,angle):
    for i in range(n):
        petal(t,r,angle)
        lt(t, 360.0/n)



wait_for_user()