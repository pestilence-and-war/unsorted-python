def node():#source input
    todo

def axon():#distance to other neurons
    todo

def dendrite():#affinity to neighboring neurons
    todo

def synapse(): #output signal to other neurons.
    todo

def plasticity():#novelty factor
    todo

def iterate(number, i = [0]): #number of iterations
    i[0] += 1
    for item in range(number):
        iterate(number-1)
    return i[0]


print(iterate(1))