def rotin(s, number = 13):
    new_word = []
    result = []
    cyph = 'abcdefghijklmnopqrstuvwxyz'
    s = s.lower()
    for letter in s:
        if letter in cyph:
            new_word.append((cyph.find(letter)+number))
        else:
            new_word.append(letter)
    for item in new_word:
        if item == ' ':
            result.append(item)
        elif str(item).isdigit():
            if item > 26:
                item = abs(item - 26)
                result.append(cyph[item-1])
            else:
                result.append(cyph[item-1])
    result = ''.join(result)

    return result


print(rotin('there once was a man named david, who killed himself', 26))
