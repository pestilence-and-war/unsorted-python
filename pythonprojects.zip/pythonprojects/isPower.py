'''A number, a, is a power of b if it is divisible by
 b and a/b is a power of b. 
 Write a function called is_power that takes 
 parameters a and b and returns True if a is a power of b.
Note: you will have to think about the base case.'''

def is_power(a,b):
    a = abs(a)
    b = abs(b)

    if b <= 1:
        return False

    else:
        while a**2 > b:
            print(a)
            if a%b != 0:
                return False
            elif a/b == 1:
                return True
            else:
                a = a/b
                #is_power(a,b)

        if a/b == 1:
            return True

        else:
            return False

'''print(is_power(531441,9))
print('\n')
print(is_power(531432, 9))
print('\n')
print(is_power(16,4))
print('\n')
print(is_power(3,3))
print('\n')
print(is_power(18,9))'''