# c = sqrt(a^2 + b^2)
import math

def area(radius):#finds the area of a circle using radius()
    temp = math.pi * radius**2
    return temp

def distance (x1, y1, x2, y2):#find the distance between two
    #points using coordinates
    dx = x2 - x1
    dy = y2 - y1
    dsquared = dx**2 + dy**2
    result = math.sqrt(dsquared)
    return result


def hypotenuse(a, b):#finds the length of the hypotenuse
    #of a right angle using the lengths of the opposite sides
    """print('side 1:\n')
    a = int(raw_input())
    print('side 2:\n')
    b = int(raw_input())"""
    result = math.sqrt(a**2 + b**2)
    return result

def circle_area(xc, yc, xp, yp):#finds the area of a circle
    #given the cordinates of two points
    """radius = distance(xc,yc,xp,yp)
    result = area(radius)
    return result"""
    return area(distance(xc, yc, xp, yp))

print(circle_area(1,2,3,4))

#hypotenuse(0,0)