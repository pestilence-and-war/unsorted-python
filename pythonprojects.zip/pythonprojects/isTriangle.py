def userIn():
    print('give side a')
    a = int(raw_input())
    print('give side b')
    b = int(raw_input())
    print('give side c')
    c = int(raw_input())
    isTriangle(a,b,c)

def isTriangle(a,b,c):
    if a > b+c or b > a+c or c > a+b:
        print('cannot make a triangle')
    elif a == b+c or b == a+c or c == a+b:
        print('this is degenerate but still a trangle')
    else:
        print ('this is a triangle')

userIn()