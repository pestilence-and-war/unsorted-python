
'''generalized Eulclid's formula for generating all pythagorean
triples is a = k*(m^2 - n^2), b = k*(2mn), c = k*(m^2 + n^2)
set k to 1'''

for m in xrange(1,32):#32^2 = 1024
    for n in xrange(1,m):#
        a = m**2 - n**2
        b = 2*m*n
        c = m**2 + n**2
        #checks and stops loop if params are met
        if a+b+c == 1000:
            print(a,b,c)
            print(a*b*c)
            break