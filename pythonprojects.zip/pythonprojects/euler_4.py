'''A palindromic sci_num reads the same both ways. 
The largest palindrome made from the product of 
two 2-digit numbers is 9009 = 91 x 99.

Find the largest palindrome made from the product of two 
3-digit numbers.'''
def palindrome_check(number):# determines if the input is a palindrome
    number = list(str(number))
    palindrome = number[::-1]
    if number == palindrome:
        return True
    else:
        return False

def create_factors(number):
    sci_num = 10**number
    limit_num = 10**(number-1)
    multi = []
    index = 0
    result = None
    for item in xrange(limit_num, sci_num):
        multi.append(item)
    while index < len(multi):
        for item in multi:
            temp = item * multi[index]
            if palindrome_check(temp) == True:
                print(item, multi[index])
                result = temp
        index += 1
    return result
