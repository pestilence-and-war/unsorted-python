def find(word, letter, start):
    index = 0
    while index < len(word):
        if word[start:index] == letter:
            return index
        index = index + 1
    return -1

#print(find('associate', 'a', 3))
def letter_count(word, letter):
    count = 0
    for item in word:
        if item == letter:
            count +=1
    print(count)

#letter_count('bobby bobkins', 'b')