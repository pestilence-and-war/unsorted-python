def frm(x,b):
    assert(x >= 0)
    assert(1<b<37)
    r = ''
    import string
    while x > 0:
        r = string.printable[x % b]+r
        x//= b
    return r
b = 2
while b<=32:
    print(frm(1,b), 'base', b)
    b+=1