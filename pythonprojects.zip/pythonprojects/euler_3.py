'''The prime factors of 13195 are 5, 7, 13 and 29.

What is the largest prime factor of the 
number 600851475143 ?'''
import math

def is_fact(number):#determines the factors of a number below sqrt
    factor1 = 1
    factors = []
    for item in xrange(number):
        if number % factor1 == 0:
            factors.insert(item, factor1)
            if factors[-1]>math.sqrt(number):#cut time by not looking further than the sqrt
                break
        factor1 += 1
    #print(factors)
    return factors

def is_prime(number):#determines if a number is prime
    factors = is_fact(number)
    list_item = [number]
    if len(factors)>2:
        return factors #returns factors of non-primes
    else:
        return list_item

def is_largest_prime(number):#find the largest prime of a number
    new = []
    count = 0
    result = 0
    lpf = is_prime(number)
    for item in lpf:
        new.append(is_prime(lpf[count]))
        count += 1
    count = 0
    for i in new:
        if len(new[count]) == 1:
            result = i[-1]
        count += 1
    #print(result)
    return result
print(is_largest_prime(125))