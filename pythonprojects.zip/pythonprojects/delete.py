from swampy.Lumpy import Lumpy

def countDown(n):
    if n <= 0:
        lumpy.object_diagram()
        print('Blastoff!')
    else:
        print(n)
        countDown(n-1)
lumpy = Lumpy()
lumpy.make_reference()

def print_n (s, n):
    if n<= 0:
        return
    print(s)
    print_n(s, n-1)

def b(z):
    prod = a(z, z)
    print z, prod
    return prod
def a(x, y):
    x = x + 1
    return x * y

def c(x, y, z):
    total = x + y + z
    square = b(total)**2
    return square

x = 1
y = x + 1
print c(x, y+3, x+y)