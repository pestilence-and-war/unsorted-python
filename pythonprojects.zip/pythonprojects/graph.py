
# coding: utf-8

# In[2]:


from bokeh.plotting import show,figure
from bokeh.io import output_notebook


# In[5]:


output_notebook()


# In[14]:


plot = figure(width=500,height=500)
plot.line(x=[0,2,3,4], y=[1,2**.5, 3, 10])
show(plot)
print("end")

