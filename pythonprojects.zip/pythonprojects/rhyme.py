#Opens a file and reads contents into memory
def open_file(filename):
    a = open(filename + ".txt", "r")
    b = a.read()
    a.close()
    return b

#Places strings into a list
def retrieve_words(filename):
    getWord = open_file(filename).split("\n")
    return getWord

#makes a dictionary so that the words are the keys and the pronunciation is the value
def split_words(filename):
    dictionary = {}
    word = retrieve_words(filename)
    #number = ('(1)','(2)','(3)')
    for i in word:
        dSpace = i.find("  ")
        k = i[0:dSpace]
        v = i[dSpace+2:]
        dictionary[k] = v
    return dictionary

#counts syllables in a word from split_words() dictionary
def syllable_count(filename, word):
    phoneme = split_words(filename)[word.upper()]
    syllableCount = 0
    for syllable in phoneme:
        if syllable in "012":
            syllableCount += 1
    return syllableCount


def rhymes(filename, word):
    rhymeList = []
    rhymePart = []
    wordDict = split_words(filename)
    phoneme = wordDict[word.upper()]
    for letter in phoneme[-1: 0: -1]:
        if letter.isdigit():
            rhymePart.append(phoneme[phoneme.index(letter)-2:])
            break
    for i in wordDict:
        if wordDict[i].endswith(rhymePart[0]):
            rhymeList.append(wordDict.keys()[wordDict.keys().index(i)])
    return sorted(rhymeList)