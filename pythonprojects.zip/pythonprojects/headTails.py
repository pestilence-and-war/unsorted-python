import random

def run_count(completedList):
    currentRun = 0
    largestRun = 0
    tally = [0, 0] # value of the longest run, longest run
    previousValue = None

    for i in completedList:
        currentRun = i
        if currentRun == previousValue:
            tally [1] += 1
            tally [0] = currentRun
            if tally [1] > largestRun:
                largestRun = tally [1]
                largestRunVal = tally [0]
        else:

            tally [1] = 1
            previousValue = currentRun
    print ([largestRunVal,largestRun])



def flip_round(flips):
    outcome = []
    for flip in range (flips):
        coin = random.randrange(2)
        outcome.append(coin)
    count_1 = 0
    count_0 = 0

    run_count(outcome)

    for item in outcome:
        if item == 0:
            count_0 += 1
        else:
            count_1 += 1
    print str(count_0) + ' zeroes', str(count_1) + ' ones'

    global countTotal0
    global countTotal1
    countTotal0 += count_0
    countTotal1 += count_1

countTotal0 = 0
countTotal1 = 0
for item in range(10):
    flip_round(100000)
    
print (countTotal0, countTotal1)