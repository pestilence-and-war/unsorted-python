
#Opens a file and reads contents into memory
def open_file(filename):
    a = open(r"C:\Users\Master\Google Drive\python projects\pythonprojects" + "\\" + filename + ".txt", "r")
    b = a.read()
    a.close()
    return b

#Places strings into a list
def retrieve_words(filename):
    getWord = open_file(filename).split("\n")
    return getWord

#Counts the number of items in the list created by retrieve_words()
def count_words(filename):
    count = 0
    get = retrieve_words(filename)
    for i in range(len(get)):
        count += 1
    return count

#bulds a list from the list returned by retrieve_words() that matches the ending prescribed
#from fileneame by rhymeScheme
def rhyme(filename, rhymeScheme):
    rhymes = retrieve_words(filename)
    wordList = []
    for word in range(len(rhymes)):
        a = str(rhymes[word])
        if len(a) > len(rhymeScheme):
            pass
        if a.endswith(rhymeScheme):
            wordList.append(a[:])
    return wordList


print (rhyme('words', 'bate'))